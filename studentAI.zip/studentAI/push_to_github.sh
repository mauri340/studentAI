#!/bin/bash
# ═══════════════════════════════════════════════════════
#  SCRIPT DI PUSH — Metodo Eureka App → GitHub
#  Esegui questo file sul tuo computer dopo aver
#  scaricato la cartella studentAI.
# ═══════════════════════════════════════════════════════

echo "🚀 Inizializzazione repository Metodo Eureka..."

# Vai nella cartella dello script
cd "$(dirname "$0")"

# Inizializza git se non esiste già
if [ ! -d ".git" ]; then
  git init
  echo "✅ Repository git inizializzato"
fi

# Configura il remote (lo aggiunge solo se non esiste)
if ! git remote | grep -q "origin"; then
  git remote add origin https://github.com/mauri340/studentAI.git
  echo "✅ Remote origin aggiunto"
else
  git remote set-url origin https://github.com/mauri340/studentAI.git
  echo "✅ Remote origin aggiornato"
fi

# Aggiungi tutti i file
git add .
echo "✅ File aggiunti"

# Commit
git commit -m "Metodo Eureka App — MindMapEngine + PAVEngine v1.0"
echo "✅ Commit eseguito"

# Push
git branch -M main
git push -u origin main

echo ""
echo "🎉 Push completato!"
echo "👉 Vai su: https://github.com/mauri340/studentAI"
